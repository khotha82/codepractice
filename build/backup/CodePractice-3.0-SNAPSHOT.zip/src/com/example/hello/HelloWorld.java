package com.example.hello;

/**
 * Created by krishna_hotha on 3/25/16.
 */
public class HelloWorld {

	public static void main(String[] args) {

		String version = System.getProperty("java.version");
		System.out.println(version);

    }
}
